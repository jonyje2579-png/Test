# ProotSpike — проверка: запускается ли proot на твоём телефоне

Одна кнопка. Результаты:
- 1) системный sh — процессы вообще запускаются;
- 2) копия бинарника из filesDir — показывает, мешает ли Android 10+ (W^X);
- 3) `libproot.so --version` из nativeLibraryDir;
- 4) запуск программы ВНУТРИ proot (`-r /`) — проверка ptrace/loader;
- 5) то же с PROOT_NO_SECCOMP=1.

## Сборка
GitHub → Actions → Build APK → Run workflow → скачать артефакт ProotSpike-apk.
Шаг "Fetch proot from Termux repo" скачивает proot автоматически (best effort).
Если он упал, положи вручную в app/src/main/jniLibs/arm64-v8a файлы
`libproot.so` (бинарник proot), `libproot-loader.so` (его loader) и `libtalloc.so`
(libtalloc.so.2 из Termux, у proot должен быть заменён NEEDED через patchelf).

## Как читать результат
- ✓ у 3 и у 4 (или 5): можно качать Debian rootfs, следующий шаг.
- ✗ у 3 с "error=13" / "Permission denied": бинарники не распаковались, проверь useLegacyPackaging.
- ✗ у 3 с "library ... not found": пришли строки NEEDED из лога шага "Fetch proot".
- ✓ у 4 только с PROOT_NO_SECCOMP=1: всегда ставь эту переменную.
