package com.spike

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val out = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(16, 16, 16, 16)
        }
        val btn = Button(this).apply { text = "Запустить тесты" }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 90, 0, 0)
        }
        root.addView(btn)
        root.addView(ScrollView(this).apply { addView(out) })
        setContentView(root)

        btn.setOnClickListener {
            out.text = ""
            btn.isEnabled = false
            thread {
                val log = { s: String -> runOnUiThread { out.append(s + "\n") } }
                try { runTests(log) } catch (e: Throwable) { log("CRASH: $e") }
                runOnUiThread { btn.isEnabled = true }
            }
        }
    }

    /** Запускает программу, ждёт до 15 с, возвращает код выхода и вывод. */
    private fun run(env: Map<String, String>, vararg cmd: String): String = try {
        val pb = ProcessBuilder(*cmd).redirectErrorStream(true)
        pb.environment().putAll(env)
        val p = pb.start()
        if (!p.waitFor(15, TimeUnit.SECONDS)) {
            p.destroyForcibly()
            "TIMEOUT (15 c)"
        } else {
            "exit=${p.exitValue()}\n" + p.inputStream.bufferedReader().readText().take(1200)
        }
    } catch (e: Exception) {
        "EXCEPTION: $e"
    }

    private fun runTests(log: (String) -> Unit) {
        val nat = applicationInfo.nativeLibraryDir
        fun check(title: String, res: String) {
            log((if (res.startsWith("exit=0")) "✓ " else "✗ ") + title)
            log(res)
            log("")
        }

        log("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), targetSdk=${applicationInfo.targetSdkVersion}")
        log("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        log("nativeLibraryDir: $nat")
        log("файлы там: " + (File(nat).list()?.sorted()?.joinToString() ?: "нет"))
        log("")

        // 1. системный sh: проверяем, что вообще можно запускать процессы
        check("1) системный /system/bin/sh", run(emptyMap(), "/system/bin/sh", "-c", "echo hello; uname -m"))

        // 2. копия бинарника в filesDir: на Android 10+ ожидаем отказ (это и есть W^X)
        val copy = File(filesDir, "sh_copy")
        val r2 = try {
            File("/system/bin/sh").copyTo(copy, overwrite = true)
            copy.setExecutable(true)
            run(emptyMap(), copy.path, "-c", "echo hi")
        } catch (e: Exception) { "EXCEPTION: $e" }
        log((if (r2.startsWith("exit=0")) "• " else "✓(ожидаемо) ") + "2) запуск копии из filesDir: " +
            if (r2.startsWith("exit=0")) "РАЗРЕШЁН (на этом телефоне W^X не мешает)" else "запрещён, значит нужен nativeLibraryDir")
        log(r2)
        log("")

        // 3-5. proot
        val proot = File(nat, "libproot.so")
        if (!proot.exists()) {
            log("✗ 3) libproot.so не найден в nativeLibraryDir. См. README: нужно положить proot в jniLibs.")
            return
        }
        val env = mutableMapOf("PROOT_TMP_DIR" to cacheDir.path, "LD_LIBRARY_PATH" to nat)
        val loader = File(nat, "libproot-loader.so")
        if (loader.exists()) env["PROOT_LOADER"] = loader.path

        check("3) proot --version", run(env, proot.path, "--version"))
        val inside = arrayOf(proot.path, "-r", "/", "/system/bin/sh", "-c", "echo inside proot; id")
        check("4) proot -r / sh (запуск программы ВНУТРИ proot)", run(env, *inside))
        check("5) то же с PROOT_NO_SECCOMP=1", run(env + ("PROOT_NO_SECCOMP" to "1"), *inside))

        log("Итог: если ✓ у пункта 3 и хотя бы у 4 или 5, то можно переходить к rootfs с Debian.")
    }
}
