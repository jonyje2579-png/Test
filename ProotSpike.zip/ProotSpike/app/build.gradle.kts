plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.spike"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.spike.proot"
        minSdk = 24
        targetSdk = 34          // специально 34: проверяем худший случай (Android 10+ W^X)
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    packaging {
        // распаковывать lib*.so на диск при установке: иначе их нельзя запустить как программы
        jniLibs { useLegacyPackaging = true }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
